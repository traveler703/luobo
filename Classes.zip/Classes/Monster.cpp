#include "Monster.h"
#include "GameScene.h"
USING_NS_CC;

bool Monster::init()
{
    if (!Target::init()){
        return false;
    }
    setAllTarget();
    return true;
}

void Monster::moveToSequence(const std::vector<cocos2d::Vec2>& positions)
{
    this->stopAllActions();    //ֹͣ��ǰ�����еĶ���

    Vector<FiniteTimeAction*> actions; // ����һ����������
    cocos2d::Vec2 thisPosition = this->getPosition();
    for (cocos2d::Vec2 position : positions)
    {
        auto distance = position - thisPosition; // �����ƶ�����
        thisPosition = position;
        auto duration = distance.length() / Speed; // �����ƶ�ʱ��
        auto move = MoveTo::create(duration, position); // �����ƶ�����
        actions.pushBack(move); // ���ƶ��������ӵ�������
    }

    auto attacked = CallFunc::create([=]() {
        auto target = this->getParent();
        auto scene = dynamic_cast<GameScene*>(target);
        scene->carrotGetHurt();
        this->setHP(0);

        });
    auto sequenceAction = Sequence::create(actions); // �������ж���
    auto sequence = Sequence::create(sequenceAction, attacked, nullptr);

    this->runAction(sequence); // ִ�����ж���
}

Blue* Blue::create(int num)
{
    Blue* BlueMon = new Blue();
    if (BlueMon && BlueMon->initial(num)) {
        BlueMon->autorelease();
        return BlueMon;
    }
    else {
        delete BlueMon;
        BlueMon = nullptr;
        return nullptr;
    }
}

bool Blue::initial(int num)
{
    if (!Sprite::init())
    {
        return false;
    }

    //��ʼ���������ۺ�����
    this->initWithFile("Blue.png");
    cocos2d::ui::Button* BlueButton = cocos2d::ui::Button::create("Blue.png");
    BlueButton->addClickEventListener([this](Ref* sender) {
        // ������ť����¼�
        setAllTarget();
        });
    BlueButton->setOpacity(0);
    BlueButton->setPosition(Vec2(50, 50));
    addChild(BlueButton);
    Num = num;
    HP = 20;
    Speed = 20;
    Value = 50;
    return true;
}

Orange* Orange::create(int num)
{
    Orange* OrangeMon = new Orange();
    if (OrangeMon && OrangeMon->initial(num)) {
        OrangeMon->autorelease();
        return OrangeMon;
    }
    else {
        delete OrangeMon;
        OrangeMon = nullptr;
        return nullptr;
    }
}

bool Orange::initial(int num)
{
    if (!Sprite::init())
    {
        return false;
    }

    //��ʼ���������ۺ�����
    this->initWithFile("Orange.png");
    cocos2d::ui::Button* OrangeButton = cocos2d::ui::Button::create("Orange.png");
    OrangeButton->addClickEventListener([this](Ref* sender) {
        // ������ť����¼�
        setAllTarget();
        });
    OrangeButton->setOpacity(0);
    OrangeButton->setPosition(Vec2(50, 50));
    addChild(OrangeButton);
    Num = num;
    HP = 30;
    Speed = 30;
    Value = 80;
    return true;
}

Pink* Pink::create(int num)
{
    Pink* PinkMon = new Pink();
    if (PinkMon && PinkMon->initial(num)) {
        PinkMon->autorelease();
        return PinkMon;
    }
    else {
        delete PinkMon;
        PinkMon = nullptr;
        return nullptr;
    }
}

bool Pink::initial(int num)
{
    if (!Sprite::init())
    {
        return false;
    }

    //��ʼ���������ۺ�����
    this->initWithFile("Pink.png");
    cocos2d::ui::Button* PinkButton = cocos2d::ui::Button::create("Pink.png");
    PinkButton->addClickEventListener([this](Ref* sender) {
        // ������ť����¼�
        setAllTarget();
        });
    PinkButton->setOpacity(0);
    PinkButton->setPosition(Vec2(50, 50));
    addChild(PinkButton);
    Num = num;
    HP = 35;
    Speed = 30;
    Value = 100;
    return true;
}
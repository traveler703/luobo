#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include"UpgradeScene.h"
#include"SelectionScene.h"
#include"SharedData.h"

UpgradeScene* UpgradeScene::create()
{
    UpgradeScene* UScene = new UpgradeScene();
    if (UScene && UScene->init()) {
        UScene->autorelease();
        return UScene;
    }
    else {
        delete UScene;
        return nullptr;
    }
}

bool UpgradeScene::init()
{
    if (!Scene::init()) {
        return false;
    }

    auto UpgradeBackground = Sprite::create("UpgradeCarrotBG.png");    //���ñ���
    UpgradeBackground->setPosition(Vec2(650, 400));
    this->addChild(UpgradeBackground);

    //����Ļ���Ͻ�λ����ʾǮ
    auto MoneySignal = Sprite::create("Money.png");
    MoneySignal->setPosition(Vec2(650, 770));
    this->addChild(MoneySignal);

    MoneyLabel = Label::createWithTTF(std::to_string(SharedData::getInstance()->UsersMoney), "fonts/Marker Felt.ttf", 32);
    MoneyLabel->setPosition(Vec2(700, 770));
    this->addChild(MoneyLabel);

    //����Ļ���Ͻ�λ����ʾ���ذ�ť
    auto Back = ui::Button::create("Back.png", "Back.png");
    Back->setPosition(Vec2(100, 750));
    Back->addClickEventListener([=](Ref* sender) {
        Director::getInstance()->replaceScene(SelectionScene::create());
    });
    this->addChild(Back);

    auto BuyWith1000= ui::Button::create("BuyWith1000.png", "BuyWith1000.png");
    auto BuyWith2000 = ui::Button::create("BuyWith2000.png", "BuyWith2000.png");
    auto BuyWith3000 = ui::Button::create("BuyWith3000.png", "BuyWith3000.png");

    BuyWith1000->setEnabled(SharedData::getInstance()->UsersMoney > 1000);
    BuyWith2000->setEnabled(SharedData::getInstance()->UsersMoney > 2000);
    BuyWith3000->setEnabled(SharedData::getInstance()->UsersMoney > 3000);

    BuyWith1000->addClickEventListener([=](Ref* sender) {
        SharedData::getInstance()->UsersMoney -= 1000;
        SharedData::getInstance()->updateHP(5);
        MoneyLabel->removeFromParent();
        MoneyLabel = Label::createWithTTF(std::to_string(SharedData::getInstance()->UsersMoney), "fonts/Marker Felt.ttf", 32);
        MoneyLabel->setPosition(Vec2(700, 770));
        this->addChild(MoneyLabel);
    });

    BuyWith2000->addClickEventListener([=](Ref* sender) {
        SharedData::getInstance()->UsersMoney -= 2000;
        SharedData::getInstance()->updateHP(10);
        MoneyLabel->removeFromParent();
        MoneyLabel = Label::createWithTTF(std::to_string(SharedData::getInstance()->UsersMoney), "fonts/Marker Felt.ttf", 32);
        MoneyLabel->setPosition(Vec2(700, 770));
        this->addChild(MoneyLabel);
    });

    BuyWith3000->addClickEventListener([=](Ref* sender) {
        SharedData::getInstance()->UsersMoney -= 3000;
        SharedData::getInstance()->updateHP(15);
        MoneyLabel->removeFromParent();
        MoneyLabel = Label::createWithTTF(std::to_string(SharedData::getInstance()->UsersMoney), "fonts/Marker Felt.ttf", 32);
        MoneyLabel->setPosition(Vec2(700, 770));
        this->addChild(MoneyLabel);
    });

    BuyWith1000->setPosition(Vec2(400, 250));
    BuyWith2000->setPosition(Vec2(650, 250));
    BuyWith3000->setPosition(Vec2(900, 250));

    this->addChild(BuyWith1000);
    this->addChild(BuyWith2000);
    this->addChild(BuyWith3000);

    return true;
}
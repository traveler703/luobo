#ifndef __SELECTION__SCENE__H__
#define __SELECTION__SCENE__H__
#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include"GameScene.h"

//ѡ��ͬ��ͼ�ĳ���
class SelectionScene :public cocos2d::Scene {
protected:
	
public:
	//����ռ�
	static SelectionScene* create();
	//��ʼ��
	virtual bool init() override;
	
};

#endif // __SELECTION__SCENE__H__

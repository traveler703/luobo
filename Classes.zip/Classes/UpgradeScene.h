#ifndef __UPGRADE__SCENE__H__
#define __UPGRADE__SCENE__H__
#include "cocos2d.h"
#include "ui/CocosGUI.h"

class UpgradeScene :public cocos2d::Scene {
public:
	//����ռ�
	static UpgradeScene* create();
	//��ʼ��
	virtual bool init() override;
	cocos2d::Label* MoneyLabel;
};
#endif // __UPGRADE__SCENE__H__

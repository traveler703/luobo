#include "WelcomeScene.h"
#include "SelectionScene.h"
#include "audio/include/SimpleAudioEngine.h"
#include "ui/CocosGUI.h"
USING_NS_CC;

WelcomeScene* WelcomeScene::create()
{
    WelcomeScene* WScene = new WelcomeScene();
    if (WScene && WScene->init()) {
        WScene->autorelease();
        return WScene;
    }
    else {
        delete WScene;
        return nullptr;
    }
}

bool WelcomeScene::init()
{
    if (!Scene::init()) {
        return false;
    }

    auto Background = Sprite::create("Welcome.png");    //���ñ���
    Background->setPosition(Vec2(650, 400));
    this->addChild(Background);

    //���ñ�������
    CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("Main.mp3");
    CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("Main.mp3", true);

    //���ÿ�ʼ��ť
    auto StartButton = ui::Button::create("StartButtonNormal.png", "StartButtonSelected.png");
    StartButton->setPosition(Vec2(650, 100));
    StartButton->addClickEventListener([=](Ref* sender) {
        Director::getInstance()->replaceScene(SelectionScene::create());
    });
    this->addChild(StartButton);

    return true;
}

#include"Bullet.h"
#include"cocos2d.h"
USING_NS_CC;

bool Bullet::init()
{
	if (!Sprite::init()) {
		return false;
	}
	return true;
}

BulletBall* BulletBall::create(Vec2 pos)
{
	BulletBall* BB = new BulletBall();
	if (BB && BB->initial(pos)) {
		BB->autorelease();
		return BB;
	}
	else {
		delete BB;
		return nullptr;
	}
}

bool BulletBall::initial(Vec2 pos)
{
	if (!Bullet::init()) {
		return false;
	}
	this->initWithFile("BulletBall.png");
	/*auto BallPic = Sprite::create("BulletBall.png");
	BallPic->setPosition(pos);
	this->getParent()->addChild(BallPic,4);*/

	MoveVelocity = 1000;
	return true;
}

void BulletBall::moveAction(Vec2 drt)
{
	//���ӷ�����Ч

	float MoveTime = sqrt(drt.x * drt.x + drt.y * drt.y) / MoveVelocity;
	auto MoveAct = MoveBy::create(MoveTime, drt);

	this->setVisible(true);

	//���ӱ�ը��Ч
}

BulletFlower* BulletFlower::create(Vec2 pos)
{
	BulletFlower* BF = new BulletFlower();
	if (BF && BF->initial(pos)) {
		BF->autorelease();
		return BF;
	}
	else {
		delete BF;
		return nullptr;
	}
}

bool BulletFlower::initial(Vec2 pos)
{
	if (!Bullet::init()) {
		return false;
	}
	this->initWithFile("BulletFlower.png");
	/*auto FlowerPic = Sprite::create("BulletFlower.png");
	FlowerPic->setPosition(pos);
	this->getParent()->addChild(FlowerPic,4);*/

	MoveVelocity = 1000;
	return true;
}

void BulletFlower::moveAction(Vec2 drt)
{
	//���ӷ�����Ч

	float MoveTime = sqrt(drt.x * drt.x + drt.y * drt.y) / MoveVelocity;

	float ExpansionRate = sqrt(drt.x * drt.x + drt.y * drt.y) / 80;
	auto ScaleXOut = ScaleTo::create(MoveTime, ExpansionRate, ExpansionRate);
	this->setVisible(true);

	//���ӱ�ը��Ч
}
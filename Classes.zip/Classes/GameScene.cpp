#include"GameScene.h"
#include"SelectionScene.h"
#include"SharedData.h"
#include"Monster.h"
#include"DefenseTower.h"
#include "audio/include/SimpleAudioEngine.h"
#include "ui/CocosGUI.h"
USING_NS_CC;

// ��ӡ���õĴ�����Ϣ�����������ļ�������ʱ�δ���
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

bool GameScene::init()
{
    if (!Scene::init()) {
        return false;
    }
    Time = 0;
    // ������ʱ������ʱ���¹���״̬
    scheduleUpdate();

    //����Ļ���Ͻ�λ����ʾǮ
    auto MoneySignal = Sprite::create("Money.png");
    MoneySignal->setPosition(Vec2(200, 770));
    this->addChild(MoneySignal,1);

    MoneyLabel = Label::createWithTTF(std::to_string(SharedData::getInstance()->UsersMoney), "fonts/Marker Felt.ttf", 32);
    MoneyLabel->setPosition(Vec2(250, 770));
    this->addChild(MoneyLabel, 1);

    setPauseButton();
    return true;
}

void GameScene::update(float dt)
{
    Time += dt;
    if (FinishedNumbers == AllNumbers) {
        int num = 0;
        // ���������е����нڵ�
        for (auto child : this->getChildren())
        {
            // �жϸýڵ��Ƿ�Ϊ Monster ����
            auto monster = dynamic_cast<Monster*>(child);
            if (monster != nullptr)
            {
                num++;
            }
        }
        if (num == 0 && CarrotHP > 0)
        {
            goBackWin();
        }
    }
}

void GameScene::showMoney()
{
    MoneyLabel->removeFromParent();
    MoneyLabel = Label::createWithTTF(std::to_string(SharedData::getInstance()->UsersMoney), "fonts/Marker Felt.ttf", 32);
    MoneyLabel->setPosition(Vec2(250, 770));
    this->addChild(MoneyLabel, 1);
}

void GameScene::generateCarrot()
{
    //���ݲ�ͬ��Ѫ�����ɲ�ͬ������
    if (CarrotHP >= 10) {
        Carrot = Sprite::create("HP_MAX.png");
    }
    else if (CarrotHP >= 9) {
        Carrot = Sprite::create("HP_9.png");
    }
    else if (CarrotHP >= 7) {
        Carrot = Sprite::create("HP_7-8.png");
    }
    else if (CarrotHP >= 5) {
        Carrot = Sprite::create("HP_5-6.png");
    }
    else if (CarrotHP >= 4) {
        Carrot = Sprite::create("HP_4.png");
    }
    else if (CarrotHP >= 3) {
        Carrot = Sprite::create("HP_3.png");
    }
    else if (CarrotHP >= 2) {
        Carrot = Sprite::create("HP_2.png");
    }
    else if (CarrotHP >= 1) {
        Carrot = Sprite::create("HP_1.png");
    }

    Carrot->setPosition(CarrotPosition);
    this->addChild(Carrot, 2);

    auto HPSignal = Sprite::create("HP.png");
    HPSignal->setPosition(CarrotPosition + Vec2(0, 50));
    this->addChild(HPSignal, 2);

    auto HPLabel= Label::createWithTTF(std::to_string(CarrotHP), "fonts/Marker Felt.ttf", 32);
    HPLabel->setPosition(CarrotPosition + Vec2(15, 50));
    this->addChild(HPLabel, 2);
}

void GameScene::carrotGetHurt(int damage)
{
    CarrotHP -= damage;
    Carrot->removeFromParent();
    if (CarrotHP <= 0) {
        goBackLost();
    }
    else {
        if (CarrotHP >= 10) {
            Carrot = Sprite::create("HP_MAX.png");
        }
        else if (CarrotHP >= 9) {
            Carrot = Sprite::create("HP_9.png");
        }
        else if (CarrotHP >= 7) {
            Carrot = Sprite::create("HP_7-8.png");
        }
        else if (CarrotHP >= 5) {
            Carrot = Sprite::create("HP_5-6.png");
        }
        else if (CarrotHP >= 4) {
            Carrot = Sprite::create("HP_4.png");
        }
        else if (CarrotHP >= 3) {
            Carrot = Sprite::create("HP_3.png");
        }
        else if (CarrotHP >= 2) {
            Carrot = Sprite::create("HP_2.png");
        }
        else if (CarrotHP >= 1) {
            Carrot = Sprite::create("HP_1.png");
        }
        Carrot->setPosition(CarrotPosition);
        this->addChild(Carrot, 2);

        auto HPLabel = Label::createWithTTF(std::to_string(CarrotHP), "fonts/Marker Felt.ttf", 32);
        HPLabel->setPosition(CarrotPosition + Vec2(50, 50));
        this->addChild(HPLabel, 2);
    }
}

void GameScene::generateMonsters(int index)
{
    
    if (index == 1) {
        MonsGeneNumbers++;
        Monster* Mon = Blue::create(MonsGeneNumbers);
        Mon->setPosition(MonsGenePosition);
        this->addChild(Mon,3);
        Mon->moveToSequence(Path);
    }
    else if (index == 2) {
        MonsGeneNumbers++;
        Monster* Mon = Pink::create(MonsGeneNumbers);
        Mon->setPosition(MonsGenePosition);
        this->addChild(Mon,3);
        Mon->moveToSequence(Path);
    }
    else if (index == 3) {
        MonsGeneNumbers++;
        Monster* Mon = Orange::create(MonsGeneNumbers);
        Mon->setPosition(MonsGenePosition);
        this->addChild(Mon,3);
        Mon->moveToSequence(Path);
    }
}

void GameScene::generateTower(std::string& mapname)
{
    auto map = TMXTiledMap::create(mapname);
    //this->addChild(map, 0);    //���ӵ������У���ʾ�ڵ�0��

    TMXObjectGroup* towerPositions = map->getObjectGroup("emptyplace");
    //����λ�ö���
    ValueVector towerPositionsVector = towerPositions->getObjects();

    for (const auto& towerPosition : towerPositionsVector)
    {
        //��ȡ����λ�ö����λ����Ϣ
        float xP = towerPosition.asValueMap().at("x").asFloat() + 50;
        float yP = towerPosition.asValueMap().at("y").asFloat() + 50;

        //��������λ�ò������ڵ�ͼ��
        Vec2 position = Vec2(xP, yP);
        TowerBase* towerPos = TowerBase::create();
        towerPos->setPosition(position);
        towerPos->setVisible(false);    //��ʼ��ʱ����Ϊ����״̬
        this->addChild(towerPos, 3);    //���ӵ������У���ʾ�ڵ�3�㣬ȷ���ڵ�ͼ�Ϸ���ʾ

    }

    // ��������¼������������ڴ�������λ�ö������ʾ������
    auto listener = EventListenerTouchOneByOne::create();
    listener->setSwallowTouches(true);
    listener->onTouchBegan = [&](Touch* touch, Event* event) {
        auto children = this->getChildren();
        for (Node* child : children)
        {
            TowerBase* towerPos = dynamic_cast<TowerBase*>(child);

            // �Ƴ����е�������ť
            if (towerPos && towerPos->TowerInThisPosition)
            {
                towerPos->TowerInThisPosition->removeChildByName("But");
                towerPos->TowerInThisPosition->removeChildByName("But");
                if (towerPos->TowerInThisPosition->bottom) {
                    towerPos->TowerInThisPosition->bottom->removeAllChildren();
                }
            }

            // ������ķ���
            if (towerPos && towerPos->getBoundingBox().containsPoint(touch->getLocation()))
            {
                //������������������
                if (towerPos->TowerInThisPosition) {
                    towerPos->setVisible(false);
                    towerPos->TowerInThisPosition->showUp_RemoveButton();
                }
                // û��������ʾ�������
                else {
                    towerPos->setVisible(true);
                    // ������ť
                    Vec2 positionButtonBottle = Vec2(40, 120);
                    Vec2 positionButtonStar = Vec2(-40, 120);
                    Vec2 positionButtonSunflower = Vec2(120, 120);
                    Vec2 positionCheck = towerPos->getPosition();
                    if (positionCheck.x == 50)      //���λ�ý������Ե���Խ����İ�ť���������д�����ʹ��ť��ʾ���Ҳ�
                    {
                        positionButtonBottle = Vec2(120, 40);
                        positionButtonStar = Vec2(120, 120);
                        positionButtonSunflower = Vec2(120, -40);
                    }
                    auto buttonBottle = cocos2d::ui::Button::create("BottleBuild.png", "BottleBuild.png", "BottleUnbuild.png");
                    buttonBottle->setPosition(positionButtonBottle);
                    buttonBottle->addClickEventListener(CC_CALLBACK_1(GameScene::generateBottle, this));  // ���Ӱ�ť����ص�����
                    // ���õ��״̬
                    buttonBottle->setEnabled(SharedData::getInstance()->UsersMoney > 100);
                    towerPos->addChild(buttonBottle, 0, "BottleButton");

                    // ������ť                  
                    auto buttonStar = cocos2d::ui::Button::create("StarBuild.png", "StarBuild.png", "StarUnbuild.png");
                    buttonStar->setPosition(positionButtonStar);
                    buttonStar->addClickEventListener(CC_CALLBACK_1(GameScene::generateStar, this));  // ���Ӱ�ť����ص�����
                    // ���õ��״̬
                    buttonStar->setEnabled(SharedData::getInstance()->UsersMoney > 200);
                    towerPos->addChild(buttonStar, 0, "StarButton");

                    // ������ť                 
                    auto buttonSunflower = cocos2d::ui::Button::create("FlowerBuild.png", "FlowerBuild.png", "FlowerUnbuild.png");
                    buttonSunflower->setPosition(positionButtonSunflower);
                    buttonSunflower->addClickEventListener(CC_CALLBACK_1(GameScene::generateFlower, this));  // ���Ӱ�ť����ص�����
                    // ���õ��״̬
                    buttonSunflower->setEnabled(SharedData::getInstance()->UsersMoney > 200);
                    towerPos->addChild(buttonSunflower, 0, "SunflowerButton");
                }
                
            }
            // û�б�����ķ���
            else if (towerPos)
            {
                towerPos->setVisible(false);

                // ���Һ��Ƴ����еĽ��찴ť
                cocos2d::ui::Button* spriteBottle = static_cast<cocos2d::ui::Button*>(this->getChildByName("BottleButton"));
                if (spriteBottle) {
                    // �ӽڵ���ڣ����Խ����Ƴ�����
                    this->removeChildByName("BottleButton");
                }

                cocos2d::ui::Button* spriteStar = static_cast<cocos2d::ui::Button*>(this->getChildByName("StarButton"));
                if (spriteStar) {
                    // �ӽڵ���ڣ����Խ����Ƴ�����
                    this->removeChildByName("StarButton");
                }

                cocos2d::ui::Button* spriteSunflower = static_cast<cocos2d::ui::Button*>(this->getChildByName("SunflowerButton"));
                if (spriteSunflower) {
                    // �ӽڵ���ڣ����Խ����Ƴ�����
                    this->removeChildByName("SunflowerButton");
                }
            }
        }
        return true;
        };

    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
}

void GameScene::generateBottle(Ref* obj)
{
    auto GeneButton = dynamic_cast<cocos2d::ui::Button*>(obj);
    if (GeneButton) {
        auto BottleTower = BottleOne::create();
        BottleTower->setPosition(GeneButton->getParent()->getPosition());
        this->addChild(BottleTower, 4);
        auto thisTowerPosition = dynamic_cast<TowerBase*> (GeneButton->getParent());
        if (thisTowerPosition)
        {
            thisTowerPosition->TowerInThisPosition = BottleTower;//
            BottleTower->thisTowerPositionIS = thisTowerPosition;//

        }
        SharedData::getInstance()->updateMoney(-100);
        showMoney();
    }
}

void GameScene::generateStar(Ref* obj)
{
    auto GeneButton = dynamic_cast<cocos2d::ui::Button*>(obj);
    if (GeneButton) {
        auto StarTower = StarOne::create();
        StarTower->setPosition(GeneButton->getParent()->getPosition());
        this->addChild(StarTower, 4);
        auto thisTowerPosition = dynamic_cast<TowerBase*> (GeneButton->getParent());
        if (thisTowerPosition)
        {
            thisTowerPosition->TowerInThisPosition = StarTower;//
            StarTower->thisTowerPositionIS = thisTowerPosition;//

        }
        SharedData::getInstance()->updateMoney(-100);
        showMoney();
    }
}

void GameScene::generateFlower(Ref* obj)
{
    auto GeneButton = dynamic_cast<cocos2d::ui::Button*>(obj);
    if (GeneButton) {
        auto FlowerTower = FlowerOne::create();
        FlowerTower->setPosition(GeneButton->getParent()->getPosition());
        this->addChild(FlowerTower, 4);
        auto thisTowerPosition = dynamic_cast<TowerBase*> (GeneButton->getParent());
        if (thisTowerPosition)
        {
            thisTowerPosition->TowerInThisPosition = FlowerTower;//
            FlowerTower->thisTowerPositionIS = thisTowerPosition;//

        }
        SharedData::getInstance()->updateMoney(-100);
        showMoney();
    }
}

void GameScene::setPauseButton()
{
    auto PauseButtom = ui::Button::create("Pause.png", "Pause.png");
    PauseButtom->setPosition(Vec2(1100, 770));    //������ͣ��ťλ��
    PauseButtom->addClickEventListener([=](Ref* sender) {
        Director::getInstance()->pause();    //��ͣ��Ϸ
        continue_Restart_GoBack();
    });
    this->addChild(PauseButtom,1);
}

void GameScene::continue_Restart_GoBack()
{
    MenuPic = Sprite::create("Menu.png");    //�˵��ĵײ�ͼƬ
    MenuPic->setPosition(Vec2(650, 400));
    this->addChild(MenuPic,6);

    ContinueGame= ui::Button::create("ContinueGameNormal.png", "ContinueGameSelected.png");    //������Ϸ�İ�ť
    ContinueGame->setPosition(Vec2(650, 512));
    ContinueGame->addClickEventListener([=](Ref* sender) {
        MenuPic->removeFromParent();
        ContinueGame->removeFromParent();
        RestartGame->removeFromParent();
        GoBackGame->removeFromParent();
        Director::getInstance()->resume();    //������Ϸ
    });
    this->addChild(ContinueGame,6);

    RestartGame= ui::Button::create("RestartGameNormal.png", "RestartGameSelected.png");    //������Ϸ�İ�ť
    RestartGame->setPosition(Vec2(650, 412));
    RestartGame->addClickEventListener([=](Ref* sender) {
        MenuPic->removeFromParent();
        ContinueGame->removeFromParent();
        RestartGame->removeFromParent();
        GoBackGame->removeFromParent();
        init();
    });
    this->addChild(RestartGame,6);

    GoBackGame = ui::Button::create("GoBackGameNormal.png", "GoBackGameSelected.png");    //����ѡ��ؿ������İ�ť
    GoBackGame->setPosition(Vec2(650, 312));
    GoBackGame->addClickEventListener([=](Ref* sender) {
        goBackBreak();
    });
    this->addChild(GoBackGame,6);
}

GameSceneOne* GameSceneOne::create()
{
    GameSceneOne* GSceneOne = new GameSceneOne();
    if (GSceneOne && GSceneOne->init()) {
        GSceneOne->autorelease();
        return GSceneOne;
    }
    else {
        delete GSceneOne;
        return nullptr;
    }
}

bool GameSceneOne::init()
{
    if (!GameScene::init()) {
        return false;
    }

    auto GSOneBackground = Sprite::create("LevelOne.png");
    GSOneBackground->setPosition(Vec2(650, 400));
    this->addChild(GSOneBackground, 0);

    MonsGenePosition = Vec2(160, 550);
    CarrotPosition = Vec2(1150, 550);

    FinishedNumbers = SharedData::getInstance()->SceneFinishedNumbers[0];
    AllNumbers = 30;
    MonsGeneNumbers = FinishedNumbers / 10 * 10;
    CarrotHP = SharedData::getInstance()->SceneCarrotHP[0];
    generateCarrot();

    std::string mapName = "LevelOne.tmx";
    generateTower(mapName);

    //scheduleUpdate();    //������ʱ������ʱ���¹���״̬

    Path =
    {
        cocos2d::Vec2(160, 550),
        cocos2d::Vec2(160, 250),
        cocos2d::Vec2(480, 250),
        cocos2d::Vec2(480, 350),
        cocos2d::Vec2(820, 350),
        cocos2d::Vec2(820, 250),
        cocos2d::Vec2(1150, 250),
        cocos2d::Vec2(1150, 550),
    };

    

    auto CreateBlue = CallFunc::create([=]() {generateMonsters(1); });
    auto CreatePink = CallFunc::create([=]() {generateMonsters(2); });
    auto CreateOrange = CallFunc::create([=]() {generateMonsters(3); });

    //���ӹ���
    runAction(Sequence::create(
        DelayTime::create(3),CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(5),    //һ�������������5�룬��������һ��
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(5),
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        
        nullptr));

    //generateTower(getClickPos());

    return true;
}

void GameSceneOne::goBackWin()
{
    auto WinBackground = Sprite::create("Win.png");
    WinBackground->setPosition(650, 400);
    this->addChild(WinBackground, 6);
    //�л�����
    CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
    CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("Main.mp3");
    CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("Main.mp3", true);
    SharedData::getInstance()->SceneSuccess[0] = true;
    SharedData::getInstance()->SceneAccess[1] = true;
    SharedData::getInstance()->SceneFinishedNumbers[0] = 0;
    SharedData::getInstance()->SceneCarrotHP[0] = SharedData::getInstance()->CarrotHPMax;
    SharedData::getInstance()->updateMoney(200);
    runAction(Sequence::create(    //�ȴ�3��
        DelayTime::create(3),
        nullptr));
    Director::getInstance()->replaceScene(SelectionScene::create());    //�ص��ؿ�ѡ�񳡾�
}

void GameSceneOne::goBackLost()
{
    auto LoseBackground = Sprite::create("Lose.png");
    LoseBackground->setPosition(650, 400);
    this->addChild(LoseBackground, 6);
    //�л�����
    CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
    CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("Main.mp3");
    CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("Main.mp3", true);
    SharedData::getInstance()->SceneFinishedNumbers[0] = 0;
    SharedData::getInstance()->SceneCarrotHP[0] = SharedData::getInstance()->CarrotHPMax;
    runAction(Sequence::create(    //�ȴ�3��
        DelayTime::create(3),
        nullptr));
    Director::getInstance()->replaceScene(SelectionScene::create());    //�ص��ؿ�ѡ�񳡾�
}

void GameSceneOne::goBackBreak()
{
    //�л�����
    CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
    CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("Main.mp3");
    CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("Main.mp3", true);
    SharedData::getInstance()->SceneFinishedNumbers[0] = FinishedNumbers;
    SharedData::getInstance()->SceneCarrotHP[0] = CarrotHP;
    Director::getInstance()->replaceScene(SelectionScene::create());    //�ص��ؿ�ѡ�񳡾�
}

GameSceneTwo* GameSceneTwo::create()
{
    GameSceneTwo* GSceneTwo = new GameSceneTwo();
    if (GSceneTwo && GSceneTwo->init()) {
        GSceneTwo->autorelease();
        return GSceneTwo;
    }
    else {
        delete GSceneTwo;
        return nullptr;
    }
}

bool GameSceneTwo::init()
{
    if (!GameScene::init()) {
        return false;
    }
    auto GSOneBackground = Sprite::create("LevelTwo.png");
    GSOneBackground->setPosition(Vec2(650, 400));
    this->addChild(GSOneBackground, 0);

    MonsGenePosition = Vec2(500, 550);
    CarrotPosition = Vec2(800, 130);

    FinishedNumbers = SharedData::getInstance()->SceneFinishedNumbers[1];
    AllNumbers = 40;
    MonsGeneNumbers = FinishedNumbers / 10 * 10;
    CarrotHP = SharedData::getInstance()->SceneCarrotHP[1];
    generateCarrot();

    std::string mapName = "LevelTwo.tmx";
    generateTower(mapName);

    //scheduleUpdate();    //������ʱ������ʱ���¹���״̬

    Path =
    {
        cocos2d::Vec2(500, 550),
        cocos2d::Vec2(1030, 550),
        cocos2d::Vec2(1030, 350),
        cocos2d::Vec2(280, 350),
        cocos2d::Vec2(280, 130),
        cocos2d::Vec2(800, 130),
        
    };



    auto CreateBlue = CallFunc::create([=]() {generateMonsters(1); });
    auto CreatePink = CallFunc::create([=]() {generateMonsters(2); });
    auto CreateOrange = CallFunc::create([=]() {generateMonsters(3); });

    //���ӹ���
    runAction(Sequence::create(
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(5),    //һ�������������5�룬��������һ��
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(5),
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(5),
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreateBlue,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreatePink,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,
        DelayTime::create(3), CreateOrange,

        nullptr));

    //generateTower(getClickPos());

    return true;
}

void GameSceneTwo::goBackWin()
{
    auto WinBackground = Sprite::create("Win.png");
    WinBackground->setPosition(650, 400);
    this->addChild(WinBackground, 6);
    //�л�����
    CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
    CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("Main.mp3");
    CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("Main.mp3", true);
    SharedData::getInstance()->SceneSuccess[1] = true;
    SharedData::getInstance()->SceneAccess[2] = true;
    SharedData::getInstance()->SceneFinishedNumbers[1] = 0;
    SharedData::getInstance()->SceneCarrotHP[1] = SharedData::getInstance()->CarrotHPMax;
    SharedData::getInstance()->updateMoney(200);
    runAction(Sequence::create(    //�ȴ�3��
        DelayTime::create(3),
        nullptr));
    Director::getInstance()->replaceScene(SelectionScene::create());    //�ص��ؿ�ѡ�񳡾�
}

void GameSceneTwo::goBackLost()
{
    auto LoseBackground = Sprite::create("Lose.png");
    LoseBackground->setPosition(650, 400);
    this->addChild(LoseBackground, 6);
    //�л�����
    CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
    CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("Main.mp3");
    CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("Main.mp3", true);
    SharedData::getInstance()->SceneFinishedNumbers[1] = 0;
    SharedData::getInstance()->SceneCarrotHP[1] = SharedData::getInstance()->CarrotHPMax;
    runAction(Sequence::create(    //�ȴ�3��
        DelayTime::create(3),
        nullptr));
    Director::getInstance()->replaceScene(SelectionScene::create());    //�ص��ؿ�ѡ�񳡾�
}

void GameSceneTwo::goBackBreak()
{
    //�л�����
    CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
    CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("Main.mp3");
    CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("Main.mp3", true);
    SharedData::getInstance()->SceneFinishedNumbers[1] = FinishedNumbers;
    SharedData::getInstance()->SceneCarrotHP[1] = CarrotHP;
    Director::getInstance()->replaceScene(SelectionScene::create());    //�ص��ؿ�ѡ�񳡾�
}

//GameSceneThree* GameSceneThree::create()
//{
//    GameSceneThree* GSceneThree = new GameSceneThree();
//    if (GSceneThree && GSceneThree->init()) {
//        GSceneThree->autorelease();
//        return GSceneThree;
//    }
//    else {
//        delete GSceneThree;
//        return nullptr;
//    }
//}
//
//bool GameSceneThree::init()
//{
//    if (!GameScene::init()) {
//        return false;
//    }
//    FinishedNumbers = SharedData::getInstance()->SceneFinishedNumbers[2];
//    scheduleUpdate();    //������ʱ������ʱ���¹���״̬
//    return true;
//}
//
//void GameSceneThree::goBackWin()
//{
//    //�л�����
//    CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
//    CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("Main.mp3");
//    CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("Main.mp3", true);
//    SharedData::getInstance()->SceneSuccess[2] = true;
//    SharedData::getInstance()->updateMoney(200);
//    SharedData::getInstance()->SceneFinishedNumbers[2] = 0;
//    SharedData::getInstance()->SceneCarrotHP[2] = SharedData::getInstance()->CarrotHPMax;
//    Director::getInstance()->replaceScene(SelectionScene::create());    //�ص��ؿ�ѡ�񳡾�
//}
//
//void GameSceneThree::goBackLost()
//{
//    //�л�����
//    CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
//    CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("Main.mp3");
//    CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("Main.mp3", true);
//    SharedData::getInstance()->SceneFinishedNumbers[2] = 0;
//    SharedData::getInstance()->SceneCarrotHP[2] = SharedData::getInstance()->CarrotHPMax;
//    Director::getInstance()->replaceScene(SelectionScene::create());    //�ص��ؿ�ѡ�񳡾�
//}
//
//void GameSceneThree::goBackBreak()
//{
//    //�л�����
//    CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
//    CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("Main.mp3");
//    CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("Main.mp3", true);
//    SharedData::getInstance()->SceneFinishedNumbers[2] = FinishedNumbers;
//    SharedData::getInstance()->SceneCarrotHP[2] = CarrotHP;
//    Director::getInstance()->replaceScene(SelectionScene::create());    //�ص��ؿ�ѡ�񳡾�
//}
#include"DefenseTower.h"
#include"GameScene.h"
#include"SharedData.h"
#include"Monster.h"
#include"cocos2d.h"
#include "ui/CocosGUI.h"
USING_NS_CC;

bool TowerBase::init()
{
    if (!Sprite::init()) {
        return false;
    }
    this->initWithFile("AddTower.png");
    TowerInThisPosition = nullptr;
    return true;
}

bool DefenseTower::init()
{
	if (!Sprite::init()) {
		return false;
	}
    Level = 1;    //��ʼ���ȼ�Ϊ1��
    tar = nullptr;
	return true;
}

void DefenseTower::update(float dt)
{
    TimeSinceLastAttack += dt;    //�ۼƾ�����ʱ��
    if (TimeSinceLastAttack >= AttackInterval) {    //������˹������ʱ�䣬�Ϳ�ʼ��������
        TimeSinceLastAttack = 0;
        attack();
    }
}

void DefenseTower::attack()
{
    // �ж��Ƿ��������
    float Distance = 0;
    if (tar && tar->isAlive()) {
        Distance = getPosition().distance(tar->getPosition());
    }

    if (tar && tar->isAlive() && Distance <= AttackRange) {
        // ����������Ŀ��
    }
    else {
        //��������
        //ѡ��������������ɵĵ���
        Vector<Node*> AttackTargets = getScene()->getChildren();
        Monster* NearestTarget = nullptr;
        int MinIndex = 10000;
        for (auto Node : AttackTargets) {
            auto Target = dynamic_cast<Monster*>(Node);
            if (Target && Target->isAlive()) {
                float Distance = getPosition().distance(Target->getPosition());
                if (Distance < AttackRange && Target->Num < MinIndex) {
                    NearestTarget = Target;
                }
            }
        }
        // ����е�������̣���������Ŀ��
        if (NearestTarget) {
            tar = NearestTarget;
        }
        else {
            tar = nullptr;
        }
    }

    // �������ȷ��Ŀ�꣬����
    if (tar && tar->isAlive()) {
        auto seq = Sequence::create(
            CallFunc::create([this]() {
                if (tar && tar->isAlive()) {
                    // ���Ź�������
                    attackAnimation(tar);
                }
            }),
            nullptr
        );
        this->runAction(seq);
    }
}

//void DefenseTower::removeTower()
//{
//    if (Level == 1) {
//        SharedData::getInstance()->updateMoney(60);
//    }
//    else if (Level == 2) {
//        SharedData::getInstance()->updateMoney(120);
//    }
//    else if (Level == 3) {
//        SharedData::getInstance()->updateMoney(180);
//    }
//    this->removeFromParentAndCleanup(true);
//}

//Bottle* Bottle::create()
//{
//    Bottle* Bt = new Bottle();
//    if (Bt && Bt->initial()) {
//        Bt->autorelease();
//        return Bt;
//    }
//    else {
//        delete Bt;
//        return nullptr;
//    }
//}

bool Bottle::init()
{
    if (!DefenseTower::init()) {
        return false;
    }
    
    return true;
}

void Bottle::attackAnimation(Target* tar)
{
    cocos2d::Vec2 Direction = tar->getPosition() - getPosition();    //����͹���ķ�������
    float TargetAngle = -CC_RADIANS_TO_DEGREES(Direction.getAngle()) + 90;    //������Ҫ��׼����ĽǶ�
    auto RotateAction = RotateTo::create(AttackInterval, TargetAngle);    //��һ��Interval��ʱ����ת

    //������ģ�⿪�𶯻�������0.1������X���������ŵ�0.8��
    //����0.1������X�����ϻָ���ԭʼ��С
    auto ScaleXOut = ScaleTo::create(0.1f, 1.0f, 0.8f);
    auto ScaleXIn = ScaleTo::create(0.1f, 1.0f, 1.0f);

    //������������
    auto SequenceAction = Sequence::create(RotateAction, ScaleXOut, ScaleXIn, nullptr);
    runAction(SequenceAction);

    auto Blt = Sprite::create("BulletBall.png");
    Blt->setPosition(this->getPosition());
    this->getParent()->addChild(Blt, 4);
    Blt->setVisible(false);

    // �ӵ�����
    auto bulletAction = CallFunc::create([=]() {
        cocos2d::Vec2 targetPosition = tar->getPosition();
        // �����ӵ���ת����
        // ����Ŀ�귽������
        cocos2d::Vec2 direction = tar->getPosition() - this->getPosition();
        // ����Ŀ��Ƕ�
        float targetAngle = -CC_RADIANS_TO_DEGREES(direction.getAngle()) + 90;
        // ��ת����
        auto rotateAction = RotateTo::create(0, targetAngle);
        // ����һ����Ŀ���ƶ��Ķ���
        float distance = targetPosition.distance(this->getPosition());
        float duration = distance / 2000; //�ӵ����ٶ�
        auto moveAction = MoveTo::create(duration, targetPosition);
        // ִ�ж���
        Blt->setVisible(true);
        Blt->runAction(
            Sequence::create(
                rotateAction,
                moveAction,
                // ����һ���ص���������Ŀ��λ�ô����ڵ���ըЧ��     
                CallFunc::create([=]() {
                    if (tar && tar->isAlive()) {
                        // ��Ŀ��λ�ô�����ըЧ��
                        auto explosion = Sprite::create("Explosion.png");
                        explosion->setPosition(targetPosition);
                        tar->getParent()->addChild(explosion);
                        explosion->runAction(Sequence::create(
                            DelayTime::create(0.1f),
                            FadeOut::create(0.1f),// ����
                            RemoveSelf::create(),
                            nullptr
                        ));
                        // �����˺�
                        tar->getHurt(Damage);
                    }
                    // �Ƴ��ڵ�����
                    this->getParent()->removeChild(Blt, true);
                    }),
                nullptr));
        });

    // ���ж���
    Blt->runAction(
        Sequence::create(
            DelayTime::create(1),
            bulletAction,
            nullptr)
    );
}

bool BottleOne::init()
{
    if (!Bottle::init()) {
        return false;
    }

    this->initWithFile("BottleLevelOne.png");
    /*auto BottlePic = Sprite::create("BottleLevelOne.png");
    Position = pos;
    BottlePic->setPosition(pos);
    this->getParent()->addChild(BottlePic, 4);*/
    AttackRange = 300;
    AttackInterval = 0.5;
    Damage = 2;
    Level = 1;
    // ������ʱ������ʱ��������״̬
    scheduleUpdate();
    return true;
}

void BottleOne::showUp_RemoveButton()
{
    Vec2 positionUp = Vec2(40, 120);
    Vec2 positionDelete = Vec2(40, -40);

    // ������ť
    auto towerUp = cocos2d::ui::Button::create("BottleUplevelOne.png", "BottleUplevelOne.png", "BottleDisuplevelOne.png");
    towerUp->setPosition(positionUp);
    towerUp->setEnabled(SharedData::getInstance()->UsersMoney > 180);
    this->bottom->addChild(towerUp, 2, "But");

    auto oldTower = this;
    Vec2 pos = oldTower->getPosition();

    // ������ť����¼�
    towerUp->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            // �ڵ�ǰλ�ô�������
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                auto tower = BottleTwo::create();  // ������������                     
                tower->setPosition(pos);  // ��������λ��
                oldTower->getParent()->addChild(tower);

                tower->thisTowerPositionIS = oldTower->thisTowerPositionIS;
                oldTower->thisTowerPositionIS->TowerInThisPosition = tower;
                
                oldTower->getParent()->addChild(tower, 4);

                SharedData::getInstance()->updateMoney(-180);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();
                
                oldTower->removeFromParent();
            }
        }
        });

    // ɾ����ť
    auto towerDelete = cocos2d::ui::Button::create("BottleRemoveOne.png", "BottleRemoveOne.png");
    towerDelete->setPosition(positionDelete);
    bottom->addChild(towerDelete, 2, "But");

    towerDelete->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                SharedData::getInstance()->updateMoney(80);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();
                oldTower->removeFromParent();
            }
        }
        });
}

bool BottleTwo::init()
{
    if (!Bottle::init()) {
        return false;
    }

    this->initWithFile("BottleLevelTwo.png");
    /*auto BottlePic = Sprite::create("BottleLevelOne.png");
    Position = pos;
    BottlePic->setPosition(pos);
    this->getParent()->addChild(BottlePic, 4);*/
    AttackRange = 350;
    AttackInterval = 0.4;
    Damage = 3;
    Level = 2;
    // ������ʱ������ʱ��������״̬
    scheduleUpdate();
    return true;
}

void BottleTwo::showUp_RemoveButton()
{
    Vec2 positionUp = Vec2(40, 120);
    Vec2 positionDelete = Vec2(40, -40);

    // ������ť
    auto towerUp = cocos2d::ui::Button::create("BottleUplevelTwo.png", "BottleUplevelTwo.png", "BottleDisuplevelTwo.png");
    towerUp->setPosition(positionUp);
    towerUp->setEnabled(SharedData::getInstance()->UsersMoney > 260);
    this->bottom->addChild(towerUp, 2, "But");

    auto oldTower = this;
    Vec2 pos = oldTower->getPosition();

    // ������ť����¼�
    towerUp->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            // �ڵ�ǰλ�ô�������
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                auto tower = BottleThree::create();  // ������������                     
                tower->setPosition(pos);  // ��������λ��
                oldTower->getParent()->addChild(tower);

                tower->thisTowerPositionIS = oldTower->thisTowerPositionIS;
                oldTower->thisTowerPositionIS->TowerInThisPosition = tower;

                oldTower->getParent()->addChild(tower, 4);

                SharedData::getInstance()->updateMoney(-260);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();

                oldTower->removeFromParent();
            }
        }
        });

    // ɾ����ť
    auto towerDelete = cocos2d::ui::Button::create("BottleRemoveTwo.png", "BottleRemoveTwo.png");
    towerDelete->setPosition(positionDelete);
    bottom->addChild(towerDelete, 2, "But");

    towerDelete->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                SharedData::getInstance()->updateMoney(224);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();
                oldTower->removeFromParent();
            }
        }
        });
}

bool BottleThree::init()
{
    if (!Bottle::init()) {
        return false;
    }

    this->initWithFile("BottleLevelThree.png");
    /*auto BottlePic = Sprite::create("BottleLevelOne.png");
    Position = pos;
    BottlePic->setPosition(pos);
    this->getParent()->addChild(BottlePic, 4);*/
    AttackRange = 400;
    AttackInterval = 0.3;
    Damage = 4;
    Level = 3;
    // ������ʱ������ʱ��������״̬
    scheduleUpdate();
    return true;
}

void BottleThree::showUp_RemoveButton()
{
    
    Vec2 positionDelete = Vec2(40, -40);
    auto oldTower = this;
    Vec2 pos = oldTower->getPosition();

    // ɾ����ť
    auto towerDelete = cocos2d::ui::Button::create("BottleRemoveThree.png", "BottleRemoveThree.png");
    towerDelete->setPosition(positionDelete);
    bottom->addChild(towerDelete, 2, "But");

    towerDelete->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                SharedData::getInstance()->updateMoney(432);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();
                oldTower->removeFromParent();
            }
        }
        });
}

bool Star::init()
{
    if (!DefenseTower::init()) {
        return false;
    }


    //this->initWithFile("StarLevelOne.png");
    ///*auto StarPic = Sprite::create("StarLevelOne.png");
    //Position = pos;
    //StarPic->setPosition(pos);
    //this->getParent()->addChild(StarPic,4);*/
    //AttackRange = 350;
    //AttackInterval = 0.4;
    //Damage = 3;
    //Level = 1;
    return true;
}

void Star::attackAnimation(Target* tar)
{
    cocos2d::Vec2 Direction = tar->getPosition() - getPosition();    //����͹���ķ�������
    float TargetAngle = -CC_RADIANS_TO_DEGREES(Direction.getAngle()) + 90;    //������Ҫ��׼����ĽǶ�
    auto RotateAction = RotateTo::create(AttackInterval, TargetAngle);    //��һ��Interval��ʱ����ת

    //������ģ�⿪�𶯻�������0.1������x��y���������ŵ�0.8��
    //����0.1������x��y�����ϻָ���ԭʼ��С
    auto ScaleXOut = ScaleTo::create(0.1f, 0.8f, 0.8f);
    auto ScaleXIn = ScaleTo::create(0.1f, 1.0f, 1.0f);

    //������������
    auto SequenceAction = Sequence::create(RotateAction, ScaleXOut, ScaleXIn, nullptr);
    runAction(SequenceAction);

    auto Blt = Sprite::create("BulletBall.png");
    Blt->setPosition(this->getPosition());
    this->getParent()->addChild(Blt, 4);
    Blt->setVisible(false);

    // �ӵ�����
    auto bulletAction = CallFunc::create([=]() {
        cocos2d::Vec2 targetPosition = tar->getPosition();
        // �����ӵ���ת����
        // ����Ŀ�귽������
        cocos2d::Vec2 direction = tar->getPosition() - this->getPosition();
        // ����Ŀ��Ƕ�
        float targetAngle = -CC_RADIANS_TO_DEGREES(direction.getAngle()) + 90;
        // ��ת����
        auto rotateAction = RotateTo::create(0, targetAngle);
        // ����һ����Ŀ���ƶ��Ķ���
        float distance = targetPosition.distance(this->getPosition());
        float duration = distance / 2000; //�ӵ����ٶ�
        auto moveAction = MoveTo::create(duration, targetPosition);
        // ִ�ж���
        Blt->setVisible(true);
        Blt->runAction(
            Sequence::create(
                rotateAction,
                moveAction,
                // ����һ���ص���������Ŀ��λ�ô����ڵ���ըЧ��     
                CallFunc::create([=]() {
                    if (tar && tar->isAlive()) {
                        // ��Ŀ��λ�ô�����ըЧ��
                        auto explosion = Sprite::create("Explosion.png");
                        explosion->setPosition(targetPosition);
                        tar->getParent()->addChild(explosion);
                        explosion->runAction(Sequence::create(
                            DelayTime::create(0.1f),
                            FadeOut::create(0.1f),// ����
                            RemoveSelf::create(),
                            nullptr
                        ));
                        // �����˺�
                        tar->getHurt(Damage);
                    }
                    // �Ƴ��ڵ�����
                    this->getParent()->removeChild(Blt, true);
                    }),
                nullptr));
        });

    // ���ж���
    Blt->runAction(
        Sequence::create(
            DelayTime::create(1),
            bulletAction,
            nullptr)
    );
}

bool StarOne::init()
{
    if (!Star::init()) {
        return false;
    }

    this->initWithFile("StarLevelOne.png");
    /*auto StarPic = Sprite::create("StarLevelOne.png");
    Position = pos;
    StarPic->setPosition(pos);
    this->getParent()->addChild(StarPic,4);*/
    AttackRange = 350;
    AttackInterval = 0.4;
    Damage = 3;
    Level = 1;
    return true;
}

void StarOne::showUp_RemoveButton()
{
    Vec2 positionUp = Vec2(40, 120);
    Vec2 positionDelete = Vec2(40, -40);

    // ������ť
    auto towerUp = cocos2d::ui::Button::create("StarUplevelOne.png", "StarUplevelOne.png", "StarDisuplevelOne.png");
    towerUp->setPosition(positionUp);
    towerUp->setEnabled(SharedData::getInstance()->UsersMoney > 220);
    this->bottom->addChild(towerUp, 2, "But");

    auto oldTower = this;
    Vec2 pos = oldTower->getPosition();

    // ������ť����¼�
    towerUp->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            // �ڵ�ǰλ�ô�������
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                auto tower = StarTwo::create();  // ������������                     
                tower->setPosition(pos);  // ��������λ��
                oldTower->getParent()->addChild(tower);

                tower->thisTowerPositionIS = oldTower->thisTowerPositionIS;
                oldTower->thisTowerPositionIS->TowerInThisPosition = tower;

                oldTower->getParent()->addChild(tower, 4);

                SharedData::getInstance()->updateMoney(-220);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();

                oldTower->removeFromParent();
            }
        }
        });

    // ɾ����ť
    auto towerDelete = cocos2d::ui::Button::create("StarRemoveOne.png", "StarRemoveOne.png");
    towerDelete->setPosition(positionDelete);
    bottom->addChild(towerDelete, 2, "But");

    towerDelete->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                SharedData::getInstance()->updateMoney(96);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();
                oldTower->removeFromParent();
            }
        }
        });
}

bool StarTwo::init()
{
    if (!Star::init()) {
        return false;
    }

    this->initWithFile("StarLevelTwo.png");
    /*auto StarPic = Sprite::create("StarLevelOne.png");
    Position = pos;
    StarPic->setPosition(pos);
    this->getParent()->addChild(StarPic,4);*/
    AttackRange = 400;
    AttackInterval = 0.3;
    Damage = 4;
    Level = 2;
    return true;
}

void StarTwo::showUp_RemoveButton()
{
    Vec2 positionUp = Vec2(40, 120);
    Vec2 positionDelete = Vec2(40, -40);

    // ������ť
    auto towerUp = cocos2d::ui::Button::create("StarUplevelTwo.png", "StarUplevelTwo.png", "StarDisuplevelTwo.png");
    towerUp->setPosition(positionUp);
    towerUp->setEnabled(SharedData::getInstance()->UsersMoney > 260);
    this->bottom->addChild(towerUp, 2, "But");

    auto oldTower = this;
    Vec2 pos = oldTower->getPosition();

    // ������ť����¼�
    towerUp->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            // �ڵ�ǰλ�ô�������
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                auto tower = StarThree::create();  // ������������                     
                tower->setPosition(pos);  // ��������λ��
                oldTower->getParent()->addChild(tower);

                tower->thisTowerPositionIS = oldTower->thisTowerPositionIS;
                oldTower->thisTowerPositionIS->TowerInThisPosition = tower;

                oldTower->getParent()->addChild(tower, 4);

                SharedData::getInstance()->updateMoney(-260);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();

                oldTower->removeFromParent();
            }
        }
        });

    // ɾ����ť
    auto towerDelete = cocos2d::ui::Button::create("StarRemoveTwo.png", "StarRemoveTwo.png");
    towerDelete->setPosition(positionDelete);
    bottom->addChild(towerDelete, 2, "But");

    towerDelete->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                SharedData::getInstance()->updateMoney(272);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();
                oldTower->removeFromParent();
            }
        }
        });
}

bool StarThree::init()
{
    if (!Star::init()) {
        return false;
    }

    this->initWithFile("StarLevelThree.png");
    /*auto StarPic = Sprite::create("StarLevelOne.png");
    Position = pos;
    StarPic->setPosition(pos);
    this->getParent()->addChild(StarPic,4);*/
    AttackRange = 450;
    AttackInterval = 0.25;
    Damage = 5;
    Level = 3;
    return true;
}

void StarThree::showUp_RemoveButton()
{
   
    Vec2 positionDelete = Vec2(40, -40);
    auto oldTower = this;
    Vec2 pos = oldTower->getPosition();

    // ɾ����ť
    auto towerDelete = cocos2d::ui::Button::create("StarRemoveThree.png", "StarRemoveThree.png");
    towerDelete->setPosition(positionDelete);
    bottom->addChild(towerDelete, 2, "But");

    towerDelete->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                SharedData::getInstance()->updateMoney(480);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();
                oldTower->removeFromParent();
            }
        }
    });
}

bool Flower::init()
{
    if (!DefenseTower::init()) {
        return false;
    }
    return true;
}

void Flower::attack()
{
    //����̷�Χ�ڵ����й�����й���
    Vector<Node*> AttackTargets = getScene()->getChildren();
    Vector<Monster*> Targets;
    for (auto Node : AttackTargets) {
        auto Target = dynamic_cast<Monster*>(Node);
        if (Target && Target->isAlive()) {
            float Distance = getPosition().distance(Target->getPosition());
            if (Distance < AttackRange) {
                Targets.pushBack(Target);
            }
        }
    }
    //����ҵ�������ʾ�������������Ź�����Ч�����Թ�����п�Ѫ
    if (!Targets.empty()) {
        attackAnimation(Targets.front());
        for (auto Node : Targets) {
            Node->getHurt(Damage);
        }
    }
}

void Flower::attackAnimation(Target* tar)
{
    cocos2d::Vec2 Direction = tar->getPosition() - getPosition();    //����͹���ķ�������

    auto Blt = Sprite::create("BulletFlower.png");
    Blt->setPosition(this->getPosition());
    this->getParent()->addChild(Blt, 4);
    
    Blt->runAction(
        Sequence::create(
            ScaleTo::create(0.15f, 3.0f, 3.0f),// ����
            FadeOut::create(0.05f),// ����
            RemoveSelf::create(),// �Ƴ��ڵ�����
            nullptr)
    );
}


bool FlowerOne::init()
{
    if (!Flower::init()) {
        return false;
    }


    this->initWithFile("FlowerLevelOne.png");
    /*auto FlowerPic = Sprite::create("FlowerLevelOne.png");
    Position = pos;
    FlowerPic->setPosition(pos);
    this->getParent()->addChild(FlowerPic,4);*/
    AttackRange = 350;
    AttackInterval = 0.4;
    Damage = 3;
    Level = 1;
    return true;
}

void FlowerOne::showUp_RemoveButton()
{
    Vec2 positionUp = Vec2(40, 120);
    Vec2 positionDelete = Vec2(40, -40);

    // ������ť
    auto towerUp = cocos2d::ui::Button::create("FlowerUplevelOne.png", "FlowerUplevelOne.png", "FlowerDisuplevelOne.png");
    towerUp->setPosition(positionUp);
    towerUp->setEnabled(SharedData::getInstance()->UsersMoney > 260);
    this->bottom->addChild(towerUp, 2, "But");

    auto oldTower = this;
    Vec2 pos = oldTower->getPosition();

    // ������ť����¼�
    towerUp->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            // �ڵ�ǰλ�ô�������
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                auto tower = FlowerTwo::create();  // ������������                     
                tower->setPosition(pos);  // ��������λ��
                oldTower->getParent()->addChild(tower);

                tower->thisTowerPositionIS = oldTower->thisTowerPositionIS;
                oldTower->thisTowerPositionIS->TowerInThisPosition = tower;

                oldTower->getParent()->addChild(tower, 4);

                SharedData::getInstance()->updateMoney(-260);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();

                oldTower->removeFromParent();
            }
        }
        });

    // ɾ����ť
    auto towerDelete = cocos2d::ui::Button::create("FlowerRemoveOne.png", "FlowerRemoveOne.png");
    towerDelete->setPosition(positionDelete);
    bottom->addChild(towerDelete, 2, "But");

    towerDelete->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                SharedData::getInstance()->updateMoney(144);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();
                oldTower->removeFromParent();
            }
        }
        });
}

bool FlowerTwo::init()
{
    if (!Flower::init()) {
        return false;
    }


    this->initWithFile("FlowerLevelTwo.png");
    /*auto FlowerPic = Sprite::create("FlowerLevelOne.png");
    Position = pos;
    FlowerPic->setPosition(pos);
    this->getParent()->addChild(FlowerPic,4);*/
    AttackRange = 400;
    AttackInterval = 0.3;
    Damage = 4;
    Level = 2;
    return true;
}

void FlowerTwo::showUp_RemoveButton()
{
    Vec2 positionUp = Vec2(40, 120);
    Vec2 positionDelete = Vec2(40, -40);

    // ������ť
    auto towerUp = cocos2d::ui::Button::create("FlowerUplevelTwo.png", "FlowerUplevelTwo.png", "FlowerDisuplevelTwo.png");
    towerUp->setPosition(positionUp);
    towerUp->setEnabled(SharedData::getInstance()->UsersMoney > 320);
    this->bottom->addChild(towerUp, 2, "But");

    auto oldTower = this;
    Vec2 pos = oldTower->getPosition();

    // ������ť����¼�
    towerUp->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            // �ڵ�ǰλ�ô�������
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                auto tower = FlowerThree::create();  // ������������                     
                tower->setPosition(pos);  // ��������λ��
                oldTower->getParent()->addChild(tower);

                tower->thisTowerPositionIS = oldTower->thisTowerPositionIS;
                oldTower->thisTowerPositionIS->TowerInThisPosition = tower;

                oldTower->getParent()->addChild(tower, 4);

                SharedData::getInstance()->updateMoney(-320);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();

                oldTower->removeFromParent();
            }
        }
        });

    // ɾ����ť
    auto towerDelete = cocos2d::ui::Button::create("FlowerRemoveTwo.png", "FlowerRemoveTwo.png");
    towerDelete->setPosition(positionDelete);
    bottom->addChild(towerDelete, 2, "But");

    towerDelete->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                SharedData::getInstance()->updateMoney(352);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();
                oldTower->removeFromParent();
            }
        }
        });
}

bool FlowerThree::init()
{
    if (!Flower::init()) {
        return false;
    }


    this->initWithFile("FlowerLevelThree.png");
    /*auto FlowerPic = Sprite::create("FlowerLevelOne.png");
    Position = pos;
    FlowerPic->setPosition(pos);
    this->getParent()->addChild(FlowerPic,4);*/
    AttackRange = 450;
    AttackInterval = 0.25;
    Damage = 5;
    Level = 3;
    return true;
}

void FlowerThree::showUp_RemoveButton()
{
    
    Vec2 positionDelete = Vec2(40, -40);
    auto oldTower = this;
    Vec2 pos = oldTower->getPosition();
        
    // ɾ����ť
    auto towerDelete = cocos2d::ui::Button::create("FlowerRemoveThree.png", "FlowerRemoveThree.png");
    towerDelete->setPosition(positionDelete);
    bottom->addChild(towerDelete, 2, "But");

    towerDelete->addClickEventListener([=](Ref* sender) {
        if (!oldTower->tar)
        {
            auto button = dynamic_cast<cocos2d::ui::Button*>(sender);
            if (button)
            {
                SharedData::getInstance()->updateMoney(608);
                dynamic_cast<GameScene*>(this->getParent())->showMoney();
                oldTower->removeFromParent();
            }
        }
        });
}
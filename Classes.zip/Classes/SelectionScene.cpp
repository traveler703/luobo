#include"SelectionScene.h"
#include"GameScene.h"
#include"SharedData.h"
#include"UpgradeScene.h"
#include "audio/include/SimpleAudioEngine.h"
#include "ui/CocosGUI.h"
USING_NS_CC;

SelectionScene* SelectionScene::create()
{
    SelectionScene* SScene = new SelectionScene();
    if (SScene && SScene->init()) {
        SScene->autorelease();
        return SScene;
    }
    else {
        delete SScene;
        return nullptr;
    }
}

bool SelectionScene::init()
{
    if (!Scene::init()) {
        return false;
    }

    auto SelectionBackground = Sprite::create("SelectionBackground.png");    //���ñ���
    SelectionBackground->setPosition(Vec2(650, 400));
    this->addChild(SelectionBackground);
    
    //����Ļ���Ͻ�λ����ʾǮ
    auto MoneySignal = Sprite::create("Money.png");
    MoneySignal->setPosition(Vec2(200, 770));
    this->addChild(MoneySignal);

    auto MoneyLable = Label::createWithTTF(std::to_string(SharedData::getInstance()->UsersMoney), "fonts/Marker Felt.ttf", 32);
    MoneyLable->setPosition(Vec2(250, 770));
    this->addChild(MoneyLable);

    //����Ļ���Ͻ�λ����ʾ�����ܲ��İ�ť
    auto Upgrade = ui::Button::create("UpgradeCarrot.png", "UpgradeCarrot.png");
    Upgrade->setPosition(Vec2(1250, 770));
    Upgrade->addClickEventListener([=](Ref* sender) {
        Director::getInstance()->replaceScene(UpgradeScene::create());
    });
    this->addChild(Upgrade);

    auto GameButtonOne = MenuItemImage::create("LevelOneNormal.png", "LevelOneNormal.png", "LevelOneNormal.png", [&](Ref* sender) {
        Director::getInstance()->replaceScene(GameSceneOne::create());
        });
    auto GameButtonTwo = MenuItemImage::create("LevelTwoNormal.png", "LevelTwoNormal.png", "LevelTwoDisabled.png", [&](Ref* sender) {
        Director::getInstance()->replaceScene(GameSceneTwo::create());
        });
    /*auto GameButtonThree = MenuItemImage::create("LevelThreeNormal.png", "LevelThreeNormal.png", "LevelThreeDisabled.png", [&](Ref* sender) {
        Director::getInstance()->replaceScene(GameSceneThree::create());
        });*/

    //�ڶ�Ӧλ�÷�����Ϸ��������ͼ
    GameButtonOne->setPosition(Vec2(350, 400));
    GameButtonTwo->setPosition(Vec2(950, 400));
    //GameButtonThree->setPosition(Vec2(350, 180));

    GameButtonOne->setEnabled(SharedData::getInstance()->SceneAccess[0]);
    GameButtonTwo->setEnabled(SharedData::getInstance()->SceneAccess[1]);
    //GameButtonThree->setEnabled(SharedData::getInstance()->SceneAccess[2]);

    auto SelectMenu = Menu::create(GameButtonOne, GameButtonTwo, nullptr);
    SelectMenu->setPosition(Vec2::ZERO);
    this->addChild(SelectMenu);

    return true;
}